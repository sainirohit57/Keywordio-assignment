import textAdImg from "./text-ad.png";

const images = {
  textAdImg: textAdImg,
};
export default images;
