import { PieChart } from "@mui/x-charts/PieChart";

const data = [
  { label: "Group A", value: 400 },
  { label: "Group B", value: 300 },
  { label: "Group C", value: 300 },
];

const AdInsightsChart = () => {
  return (
    <PieChart
      series={[
        {
          data: data,
          innerRadius: 100,
          outerRadius: 150,
          paddingAngle: 2,
          cx: 250,
          cy: 200,
        },
      ]}
      height={418}
      //   sx={{
      //     position: "absolute",
      //     top: 0,
      //     left: "0% !important",
      //     // transform: "translateX(-50%)", // Center horizontally
      //   }}
      slotProps={{
        legend: {
          direction: "column",
          position: {
            vertical: "middle",
            horizontal: "right",
          },
          itemMarkWidth: 58,
          itemMarkHeight: 16,
          markGap: 12,
          itemGap: 24,
        },
      }}
    />
  );
};

export default AdInsightsChart;
