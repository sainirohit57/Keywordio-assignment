import { Button, Grid } from "@mui/material";
import MediaCard from "./MediaCard";

const CreateAds = () => {
  return (
    <div className="page-layout item-flex">
      <h3>Create Ads</h3>
      <Grid container spacing={5} sx={{ paddingY: "32px" }}>
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            "& .MuiPaper-root": {
              marginLeft: "auto",
            },
          }}
        >
          <MediaCard title={"Text Ad"} />
        </Grid>
        <Grid item xs={12} md={6}>
          <MediaCard title={"Media Ad"} />
        </Grid>
      </Grid>
      <div className="text-end">
        <Button className="primary-btn">Next</Button>
      </div>
    </div>
  );
};

export default CreateAds;
