import { Grid } from "@mui/material";
import { Tabs, TabsList, TabPanel, Tab } from "@mui/base";
import DonutLargeIcon from "@mui/icons-material/DonutLarge";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import AdTable from "./AdTable";
import AdInsightsChart from "./AdInsightsChart";

const tableColumns = [
  {
    field: "campaigns",
    headerName: "Campaigns",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "clicks",
    headerName: "Clicks",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "cost",
    headerName: "Cost",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "conversions",
    headerName: "Conversions",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "revenue",
    headerName: "Revenue",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
];

const tableRows = [
  {
    id: 1,
    campaigns: "Snow",
    clicks: 712,
    cost: "USD 8399",
    conversions: 35,
    revenue: "USD 4353",
  },
  {
    id: 2,
    campaigns: "Lannister",
    clicks: 234,
    cost: "USD 8399",
    conversions: 42,
    revenue: "USD 4353",
  },
  {
    id: 3,
    campaigns: "Lannister",
    clicks: 243,
    cost: "USD 8399",
    conversions: 45,
    revenue: "USD 4353",
  },
  {
    id: 4,
    campaigns: "Stark",
    clicks: 5633,
    cost: "USD 8399",
    conversions: 16,
    revenue: "USD 4353",
  },
  {
    id: 5,
    campaigns: "Targaryen",
    clicks: 3652,
    cost: "USD 8399",
    conversions: 43,
    revenue: "USD 4353",
  },
  {
    id: 6,
    campaigns: "Melisandre",
    clicks: 234,
    cost: "USD 8399",
    conversions: 150,
    revenue: "USD 4353",
  },
  {
    id: 7,
    campaigns: "Clifford",
    clicks: 245,
    cost: "USD 8399",
    conversions: 44,
    revenue: "USD 4353",
  },
];

const chartColumns = [
  {
    field: "campaigns",
    headerName: "Campaigns",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "clicks",
    headerName: "Clicks",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "cost",
    headerName: "Cost",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "conversions",
    headerName: "Conversions",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
  {
    field: "revenue",
    headerName: "Revenue",
    type: "number",
    flex: 1,
    headerClassName: "custom-header",
    cellClassName: "custom-cell",
  },
];

const chartRows = [
  {
    id: 1,
    campaigns: "Snow",
    clicks: 712,
    cost: "USD 8399",
    conversions: 35,
    revenue: "USD 4353",
  },
  {
    id: 2,
    campaigns: "Lannister",
    clicks: 234,
    cost: "USD 8399",
    conversions: 42,
    revenue: "USD 4353",
  },
  {
    id: 3,
    campaigns: "Lannister",
    clicks: 243,
    cost: "USD 8399",
    conversions: 45,
    revenue: "USD 4353",
  },
  {
    id: 4,
    campaigns: "Stark",
    clicks: 5633,
    cost: "USD 8399",
    conversions: 16,
    revenue: "USD 4353",
  },
];

const Home = () => {
  return (
    <Grid container spacing={4}>
      <Grid item xs={12} md={6}>
        <div className="table-box">
          <div className="table-box-header">
            <h3>Ad Insights</h3>
          </div>
          <AdTable rows={tableRows} columns={tableColumns} />
        </div>
      </Grid>
      <Grid item xs={12} md={6}>
        <div className="table-box">
          <div className="table-box-header">
            <h3>Ad Insights</h3>
          </div>
          <Tabs defaultValue={1} className="custom-tabs">
            <TabsList className="tabs-list">
              <Tab value={1}>
                <DonutLargeIcon />
              </Tab>
              <Tab value={2}>
                <TableChartOutlinedIcon />
              </Tab>
            </TabsList>
            <TabPanel value={1}>
              <AdInsightsChart />
            </TabPanel>
            <TabPanel value={2}>
              <AdTable rows={chartRows} columns={chartColumns} />
            </TabPanel>
          </Tabs>
        </div>
      </Grid>
    </Grid>
  );
};

export default Home;
