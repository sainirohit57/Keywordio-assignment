import CheckCircleIcon from "@mui/icons-material/CheckCircle";

const SuccessPage = () => {
  return (
    <div className="page-layout item-flex success-card">
      <div className="card">
        <CheckCircleIcon className="icon" />
        <h3 className="title">Submitted</h3>
      </div>
    </div>
  );
};

export default SuccessPage;
